const express = require('express');
const app = express();
const port = 3010;
const path = require('path');
var { instagram } = require('instagram-scraper-api');

app.use(async (req, res, next) => {
  next();
});
app.get('/', async (req, res) => {
  const data = await instagram.user('willsmith');

  return res.json(data);
});

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});
